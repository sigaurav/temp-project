Andrei Antoukh / niwibe <https://github.com/niwibe>
Sean Bleier <https://github.com/sebleier>
Matt Dennewitz <https://github.com/blackbrrr>
Jannis Leidel <https://github.com/jezdez>
S. Angel / Twidi <https://github.com/twidi>
Noah Kantrowitz / coderanger <https://github.com/coderanger>
Martin Mahner / bartTC <https://github.com/bartTC>
Timothée Peignier / cyberdelia <https://github.com/cyberdelia>
Lior Sion / liorsion <https://github.com/liorsion>
Ales Zoulek / aleszoulek <https://github.com/aleszoulek>
James Aylett / jaylett <https://github.com/jaylett>
Todd Boland / boland <https://github.com/boland>
David Zderic / dzderic <https://github.com/dzderic>
Kirill Zaitsev / teferi <https://github.com/teferi>
Jon Dufresne <https://github.com/jdufresne>
Anès Foufa <https://github.com/AnesFoufa>
