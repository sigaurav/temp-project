# This indicates a parameter key should be specified for every argument. e.g. --foo 1 --foo 2 instead
# of --foo 1 2
SPECIFY_EVERY_PARAM = 'specify_every_param'