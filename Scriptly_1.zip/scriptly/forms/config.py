SCRIPTLY_MULTI_WIDGET_ATTR = "data-scriptly-multiple"
SCRIPTLY_MULTI_WIDGET_ANCHOR = "scriptly-multi-input"
