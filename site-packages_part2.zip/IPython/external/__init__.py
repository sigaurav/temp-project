"""
This package contains all third-party modules bundled with IPython.
"""

from typing import List

__all__: List[str] = []
