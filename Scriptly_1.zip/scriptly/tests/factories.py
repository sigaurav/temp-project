import sys
import tempfile

import factory
from django.contrib.auth import get_user_model

from ..models import (
    APIKey,
    Script,
    ScriptGroup,
    VirtualEnvironment,
    ScriptlyJob,
    ScriptlyProfile,
    ScriptlyWidget,
)
from . import utils as test_utils


class ScriptGroupFactory(factory.DjangoModelFactory):
    class Meta:
        model = ScriptGroup

    group_name = "test group"
    group_description = "test desc"


class ScriptParameterGroupFactory(factory.DjangoModelFactory):
    class Meta:
        model = "scriptly.ScriptParameterGroup"


class ScriptParameterFactory(factory.DjangoModelFactory):
    class Meta:
        model = "scriptly.ScriptParameter"

    script_param = "script-param"
    is_output = False
    parameter_group = factory.SubFactory(
        "scriptly.tests.factories.ScriptParameterGroupFactory"
    )
    parser = factory.SubFactory("scriptly.tests.factories.ScriptParserFactory")


class ScriptParserFactory(factory.DjangoModelFactory):
    class Meta:
        model = "scriptly.ScriptParser"


class ScriptFactory(factory.DjangoModelFactory):
    class Meta:
        model = Script

    script_name = "test script"
    script_group = factory.SubFactory(ScriptGroupFactory)
    script_description = "test script desc"


class UserFactory(factory.DjangoModelFactory):
    class Meta:
        model = get_user_model()
        django_get_or_create = ("username",)

    username = "user"
    email = "a@a.com"
    password = "testuser"


class ProfileFactory(factory.DjangoModelFactory):
    class Meta:
        model = ScriptlyProfile
        django_get_or_create = ("user",)

    user = factory.SubFactory("scriptly.tests.factories.UserFactory")


class APIKeyFactory(factory.DjangoModelFactory):
    class Meta:
        model = APIKey

    name = factory.Sequence(lambda n: "api key %d" % n)
    profile = factory.SubFactory("scriptly.tests.factories.ProfileFactory")


class BaseJobFactory(factory.DjangoModelFactory):
    class Meta:
        model = ScriptlyJob

    job_name = "\xd0\xb9\xd1\x86\xd1\x83"
    job_description = "\xd0\xb9\xd1\x86\xd1\x83\xd0\xb5\xd0\xba\xd0\xb5"


class ScriptlyWidgetFactory(factory.DjangoModelFactory):
    class Meta:
        model = ScriptlyWidget

    name = "test widget"


class VirtualEnvFactory(factory.DjangoModelFactory):
    class Meta:
        model = VirtualEnvironment

    name = factory.Sequence(lambda n: "venv_%d" % n)
    python_binary = sys.executable
    venv_directory = tempfile.gettempdir()


def generate_script(script_path, script_name=None, ignore_bad_imports=False):
    new_file = test_utils.save_script_path(script_path)
    from ..backend import utils

    res = utils.add_scriptly_script(
        script_name=script_name,
        script_path=new_file,
        group=None,
        ignore_bad_imports=ignore_bad_imports,
    )
    return res["script"]


def generate_job(script_version):
    return BaseJobFactory(script_version=script_version)
